import 'dart:async';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';

class SpeechService {
  final SpeechToText _speech = SpeechToText();
  final _liveController = StreamController<String>.broadcast();
  final List<String> _buffer = [];
  BluetoothCharacteristic? _writeCharacteristic;
  BluetoothCharacteristic? _notifyCharacteristic;
  StreamSubscription<List<int>>? _notifyListener;
  int _sendIndex = 0;

  Stream<String> get liveTranscript => _liveController.stream;

  Future<void> init() async {
    await Permission.microphone.request();
    bool available = await _speech.initialize(
      onStatus: _onStatus,
      onError: _onError,
    );
    if (!available) {
      throw Exception('Speech recognition unavailable');
    }
  }

  void setupBLE({
    required BluetoothCharacteristic writeCharacteristic,
    required BluetoothCharacteristic notifyCharacteristic,
  }) {
    _writeCharacteristic = writeCharacteristic;
    _notifyCharacteristic = notifyCharacteristic;

    _notifyCharacteristic!.setNotifyValue(true);
    _notifyListener = _notifyCharacteristic!.onValueReceived.listen((data) {
      final str = String.fromCharCodes(data).trim();
      if (str == "next") {
        _sendNextCharacter();
      }
    });
  }

  Future<void> startListening() async {
    await _speech.listen(
      onResult: _onSpeechResult,
      listenMode: ListenMode.dictation,
      partialResults: true,
      cancelOnError: false,
    );
  }

  Future<void> stopListening() async {
    await _speech.stop();
  }

  void dispose() {
    _liveController.close();
    _notifyListener?.cancel();
  }

  void _onSpeechResult(SpeechRecognitionResult result) {
    _liveController.add(result.recognizedWords);
  }

  void _onStatus(String status) {
    if (status == 'done' || status == 'notListening') {
      Future.delayed(const Duration(milliseconds: 500), () {
        if (!_speech.isListening) {
          startListening();
        }
      });
    }
  }

  void _onError(SpeechRecognitionError error) {
    Future.delayed(const Duration(seconds: 1), () {
      if (!_speech.isListening) {
        startListening();
      }
    });
  }

  void sendInput(String input) {
    _buffer.clear();
    _buffer.addAll(input.split(''));
    _sendIndex = 0;
    if (_buffer.isNotEmpty) {
      _sendNextCharacter();
    }
  }

  void _sendNextCharacter() {
    if (_sendIndex < _buffer.length && _writeCharacteristic != null) {
      String charToSend = _buffer[_sendIndex];
      _writeCharacteristic!.write(charToSend.codeUnits, withoutResponse: true);
      _sendIndex++;
    }
  }
}
