import 'dart:async';
import 'dart:typed_data';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:permission_handler/permission_handler.dart';

class CustomBluetoothService {
  BluetoothDevice? selectedDevice;
  StreamSubscription<List<int>>? streamSub;
  final List<Message> buffer = [];

  final Guid serviceUuid = Guid("4fafc201-1fb5-459e-8fcc-c5c9c331914b");
  final Guid charTxUuid = Guid("beb5483e-36e1-4688-b7f5-ea07361b26a8");
  final Guid charRxUuid = Guid("6e400003-b5a3-f393-e0a9-e50e24dcca9e");

  BluetoothCharacteristic? _writeCharacteristic;

  Future<void> getPermissions() async {
    await Permission.bluetooth.request();
    await Permission.bluetoothScan.request();
    await Permission.bluetoothConnect.request();
    await Permission.location.request();
  }

  Future<void> connectToDevice(
    BluetoothDevice device,
    int state,
    Function(bool) onUpdate,
  ) async {
    selectedDevice = device;

    if (state == 1) {
      selectedDevice!.state.listen((event) {
        onUpdate(event == BluetoothConnectionState.connected);
      });
    } else {
      onUpdate(false);
    }

    await selectedDevice!.connect(autoConnect: false);
    selectedDevice!.connectionState.listen((event) async {
      onUpdate(event == BluetoothConnectionState.connected);
      if (event == BluetoothConnectionState.disconnected) {
        await streamSub?.cancel();
      }
    });

    List<BluetoothService> services = await selectedDevice!.discoverServices();
    for (var service in services) {
      if (service.uuid == serviceUuid) {
        for (var chara in service.characteristics) {
          if (chara.uuid == charTxUuid) {
            await chara.setNotifyValue(true);
            streamSub = chara.onValueReceived.listen((value) {
              final str = String.fromCharCodes(value);
              if (str.startsWith("[NUMERIC]")) {
                buffer.add(Message(str, 1));
              } else {
                buffer.add(Message(str, 0));
              }
            });
          }
          if (chara.uuid == charRxUuid) {
            _writeCharacteristic = chara;
          }
        }
      }
    }
  }

  Future<void> sendCharacterToESP32(String char) async {
    if (selectedDevice == null || _writeCharacteristic == null) return;
    await _writeCharacteristic!.write(Uint8List.fromList(char.codeUnits), withoutResponse: true);
  }

  List<Message> getMessages() => List.unmodifiable(buffer);

  Stream<List<BluetoothDevice>> getSystemDevicesStream() {
    return Stream.periodic(const Duration(seconds: 10)).asyncMap((_) => FlutterBluePlus.systemDevices([]));
  }

  Stream<List<ScanResult>> get scanResults => FlutterBluePlus.scanResults;
  Future<void> startScan() => FlutterBluePlus.startScan(timeout: const Duration(seconds: 4));
  Future<void> stopScan() => FlutterBluePlus.stopScan();
  Stream<bool> get isScanning => FlutterBluePlus.isScanning;
  Stream<BluetoothAdapterState> get adapterState => FlutterBluePlus.adapterState;
}

class Message {
  final String data;
  final int source;
  Message(this.data, this.source);
}
