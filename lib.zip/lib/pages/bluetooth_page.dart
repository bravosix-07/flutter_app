import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import '../services/bluetooth_service.dart';
import 'package:tflite_flutter/tflite_flutter.dart';

class BluetoothPage extends StatefulWidget {
  final Function({
    required BluetoothCharacteristic writeCharacteristic,
    required BluetoothCharacteristic notifyCharacteristic,
  })? onConnected;

  const BluetoothPage({Key? key, this.onConnected}) : super(key: key);

  @override
  _BluetoothPageState createState() => _BluetoothPageState();
}

class _BluetoothPageState extends State<BluetoothPage> {
  final CustomBluetoothService _bluetoothService = CustomBluetoothService();
  bool isConnected = false;
  BluetoothDevice? connectedDevice;
  List<ScanResult> availableDevices = [];
  List<Message> _messages = [];
  String currentlySentChar = "";

  List<int> _flexSensorValues = [0, 0, 0, 0, 0];
  String _prediction = "Waiting for prediction...";
  Interpreter? _interpreter;

  @override
  void initState() {
    super.initState();
    _bluetoothService.getPermissions();
    _startScan();
    _loadModel();
    _startMessageListener();
  }

  @override
  void dispose() {
    _interpreter?.close();
    super.dispose();
  }

  Future<void> _loadModel() async {
    try {
      _interpreter = await Interpreter.fromAsset('assets/model.tflite');
      print("[Model] Model loaded successfully.");
    } catch (e) {
      print("[Model] Error loading model: $e");
    }
  }

  void _startScan() {
    FlutterBluePlus.startScan(timeout: const Duration(seconds: 5));
    FlutterBluePlus.scanResults.listen((results) {
      setState(() {
        availableDevices = results;
      });
    });
  }

  void _startMessageListener() {
    Timer.periodic(const Duration(milliseconds: 500), (_) {
      setState(() {
        _messages = _bluetoothService.getMessages().reversed.toList();
      });

      for (var msg in _messages) {
        if (msg.source == 1) {
          _processFlexData(msg.data);
        }
      }
    });
  }

  void _processFlexData(String data) {
    if (data.startsWith("[NUMERIC]")) {
      try {
        final values = data.replaceAll("[NUMERIC] ", "").trim().split(",");
        if (values.length == 5) {
          List<int> flex = values.map((v) => int.parse(v)).toList();
          setState(() {
            _flexSensorValues = flex;
          });
          _runPrediction(flex.map((e) => e.toDouble()).toList());
        }
      } catch (e) {
        print("[BLE] Error processing flex data: $e");
      }
    }
  }

  void _runPrediction(List<double> input) async {
    if (_interpreter == null) return;
    final output = List.filled(1, 0.0);
    try {
      _interpreter!.run([input], output);
      setState(() {
        _prediction = "Prediction: ${output[0].toStringAsFixed(2)}";
      });
    } catch (e) {
      print("[Model] Prediction error: $e");
    }
  }

  Future<void> _connectToDevice(BluetoothDevice device) async {
    try {
      await device.connect(autoConnect: false);
      print("[BLE] Connected to ${device.platformName}");

      List<BluetoothService> services = await device.discoverServices();
      BluetoothCharacteristic? writeChar;
      BluetoothCharacteristic? notifyChar;

      for (var service in services) {
        for (var chara in service.characteristics) {
          if (chara.properties.write) {
            writeChar = chara;
          }
          if (chara.properties.notify) {
            notifyChar = chara;
          }
        }
      }

      if (writeChar != null && notifyChar != null) {
        await notifyChar.setNotifyValue(true);

        widget.onConnected!(
          writeCharacteristic: writeChar,
          notifyCharacteristic: notifyChar,
        );

        connectedDevice = device;
        setState(() {
          isConnected = true;
        });
      }
    } catch (e) {
      print("[BLE] Connection error: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Bluetooth Devices')),
      body: SingleChildScrollView(
        child: Column(
          children: [
            isConnected
                ? Column(
                    children: [
                      ListTile(
                        title: Text(connectedDevice?.platformName.isNotEmpty == true
                            ? connectedDevice!.platformName
                            : connectedDevice!.remoteId.str),
                        subtitle: const Text("Status: Connected"),
                        trailing: ElevatedButton(
                          onPressed: () async {
                            await connectedDevice?.disconnect();
                            setState(() {
                              isConnected = false;
                              connectedDevice = null;
                            });
                          },
                          child: const Text("Disconnect"),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text("Currently Sending: $currentlySentChar",
                          style: const TextStyle(fontSize: 18)),
                    ],
                  )
                : Column(
                    children: availableDevices.map((result) {
                      final name = result.device.platformName.isNotEmpty
                          ? result.device.platformName
                          : result.device.remoteId.str;
                      return ListTile(
                        title: Text(name),
                        trailing: ElevatedButton(
                          onPressed: () {
                            _connectToDevice(result.device);
                          },
                          child: const Text("Connect"),
                        ),
                      );
                    }).toList(),
                  ),
            const Divider(),
            const Padding(
              padding: EdgeInsets.all(8.0),
              child: Text("Flex Sensor Values", style: TextStyle(fontWeight: FontWeight.bold)),
            ),
            for (int i = 0; i < 5; i++)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 4),
                child: Text(
                  "Finger ${i + 1}: ${_flexSensorValues[i]}",
                  style: const TextStyle(fontSize: 16),
                ),
              ),
            const Divider(),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                _prediction,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
              ),
            ),
            const Divider(),
            Container(
              height: 200,
              child: ListView.builder(
                itemCount: _messages.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(_messages[index].data),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _startScan,
        child: const Icon(Icons.search),
      ),
    );
  }
}
