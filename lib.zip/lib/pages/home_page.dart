import 'package:flutter/material.dart';
import 'speech_page.dart';
import 'bluetooth_page.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;
  BluetoothCharacteristic? writeCharacteristic;
  BluetoothCharacteristic? notifyCharacteristic;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  void _setCharacteristics({
    required BluetoothCharacteristic writeCharacteristic,
    required BluetoothCharacteristic notifyCharacteristic,
  }) {
    setState(() {
      this.writeCharacteristic = writeCharacteristic;
      this.notifyCharacteristic = notifyCharacteristic;
      _selectedIndex = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    List<Widget> pages = [
      if (writeCharacteristic != null && notifyCharacteristic != null)
        SpeechPage(
          writeCharacteristic: writeCharacteristic!,
          notifyCharacteristic: notifyCharacteristic!,
        )
      else
        const Center(child: Text('Connect to a device first!')),
      BluetoothPage(onConnected: _setCharacteristics),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Real-time Assistant'),
        backgroundColor: Colors.deepPurple,
      ),
      body: pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.deepPurple,
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.mic), label: 'SPEECH'),
          BottomNavigationBarItem(icon: Icon(Icons.bluetooth), label: 'BLUETOOTH'),
        ],
      ),
    );
  }
}
