import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import '../services/speech_to_text.dart';

class SpeechPage extends StatefulWidget {
  final BluetoothCharacteristic writeCharacteristic;
  final BluetoothCharacteristic notifyCharacteristic;

  const SpeechPage({Key? key, required this.writeCharacteristic, required this.notifyCharacteristic})
      : super(key: key);

  @override
  State<SpeechPage> createState() => _SpeechPageState();
}

class _SpeechPageState extends State<SpeechPage> {
  final SpeechService _speechService = SpeechService();
  final TextEditingController _textController = TextEditingController();
  String _liveSpeech = "";
  bool _isListening = false;

  @override
  void initState() {
    super.initState();
    _speechService.init();
    _speechService.setupBLE(
      writeCharacteristic: widget.writeCharacteristic,
      notifyCharacteristic: widget.notifyCharacteristic,
    );

    _speechService.liveTranscript.listen((text) {
      setState(() {
        _liveSpeech = text;
      });
    });
  }

  @override
  void dispose() {
    _speechService.dispose();
    _textController.dispose();
    super.dispose();
  }

  void _sendInput() {
    final input = _textController.text.trim();
    if (input.isNotEmpty) {
      _speechService.sendInput(input);
      _textController.clear();
    }
  }

  void _toggleListening() {
    if (_isListening) {
      _speechService.stopListening();
    } else {
      _speechService.startListening();
    }
    setState(() {
      _isListening = !_isListening;
    });
  }

  void _copyLiveSpeech() {
    _textController.text = _liveSpeech;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _textController,
              decoration: const InputDecoration(
                labelText: 'Type or Copy from Speech',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: _sendInput,
              child: const Text('Send Input to ESP32'),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                ElevatedButton.icon(
                  onPressed: _toggleListening,
                  icon: Icon(_isListening ? Icons.mic_off : Icons.mic),
                  label: Text(_isListening ? 'Stop Listening' : 'Start Listening'),
                ),
                const SizedBox(width: 20),
                ElevatedButton.icon(
                  onPressed: _copyLiveSpeech,
                  icon: const Icon(Icons.copy),
                  label: const Text('Copy Speech'),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Text(
              'Live Speech: $_liveSpeech',
              style: const TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}
